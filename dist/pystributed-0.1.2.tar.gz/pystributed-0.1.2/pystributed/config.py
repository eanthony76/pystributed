
DOCKER_IMAGE_NAME = "pystributed_image"
DOCKERFILE_PATH = "./Dockerfile"
DOCKER_REGISTRY = "docker.io/myusername"
REMOTE_SERVER = "user@remote_server_ip"
REMOTE_WORKDIR = "/path/on/remote/server"
USER_CODE_PATH = "/mnt/data/user_code.py"

SSH_PRIVATE_KEY_PATH = '/path/to/private_key.pem'
